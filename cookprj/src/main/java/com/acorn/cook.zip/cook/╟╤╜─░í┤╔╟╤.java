package com.acorn.cook;

interface 한식가능한{
    public String   된장찌게만들기();
    public String  불고기만들기();
    public String  김밥만들기();

}