package com.acorn.cook;

interface 중식가능한{
    public String  마라탕만들기();
    public String  탕수육만들기();
    public String 짜장면만들기();
}
