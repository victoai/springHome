package com.acorn.btran;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

 
public class MemberService { 	 
	MemberDao dao; 

}
