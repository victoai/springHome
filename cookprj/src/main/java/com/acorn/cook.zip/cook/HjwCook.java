package com.acorn.cook;

public class HjwCook   extends Cook implements 양식가능한{

	  
	public HjwCook(){}
	public HjwCook(String name ){
		super(name);
		
	}
	@Override
	public String 스파게티만들기() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String 피자만들기() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String 돈까스만들기() {
		// TODO Auto-generated method stub
		return null;
	}
	 
}
