package com.acorn.dbtran;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

public class MemberService2Test {
	
	@Autowired
    MemberService2 service;
	
	
	@Test
	public void testInsertA1WithTx2() {
		
	
	 
	}
		 

}
